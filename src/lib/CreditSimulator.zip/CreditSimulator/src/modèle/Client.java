package modèle;

public class Client {
}
