package jdbc;

public class TestJDBC {
    public static void main(String[] args)
    {
        String url="jdbc:mysql;//localhost:3306/bakati",
        UserName="bankUser",
        Password="banker";

    }
}
