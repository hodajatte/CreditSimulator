package jdbc;

public class Singleton {

}
