package dao.daoMysql;

import dao.IDao;
import dao.daoExceptions.DAOConfigException;
import modèle.Crédit;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class FactoryMySQL {
    private  static final String PROPERTIES_FILE="dao/dao.properties",
    URL ="SDB_URL",
    DB ="DB_NAME",
    LOGIN ="SDB_LOGIN",
    PASS ="SDB_PASS",
    DRIVER ="SDB_DRIVER";

    public static FactoryMySQL INSTANCE=getInstance();
    public static Connection connection;
    private String url,login,pass;
    private  FactoryMySQL(String url,String login,String pass)throws SQLException{
        this.url=url;
        this.login=login;
        this.pass=pass;
        connection= DriverManager.getConnection(url,login,pass);

    }
    public static FactoryMySQL getInstance() throws DAOConfigException {
        //Notre instance restera null tout que nos contraintes n'ont pas été vérifié
        String property_URL,property_DBNAME ,property_LOGIN,property_PASS,property_DRIVER;
        Properties properties=new Properties();
        ClassLoader classLoader=Thread.currentThread().getContextClassLoader();
        InputStream propertiesFile=classLoader.getResourceAsStream(PROPERTIES_FILE);
        if(propertiesFile ==null) {
            throw new DAOConfigException(PROPERTIES_FILE + "est introuvable !!!");
        }
            else{
            //Contrainte n° 1 vérifie :Fichier dao.properties est accessible
        }
            try{
                 properties.load(propertiesFile);
                 property_URL=properties.getProperty(URL);
                 property_DBNAME =properties.getProperty(DB);
                 property_LOGIN =properties.getProperty(LOGIN);
                 property_PASS =properties.getProperty(PASS);
                 property_DRIVER=properties.getProperty(DRIVER);
                 propertiesFile.close();
                 //Contrtraines n° 2 vérifié :les données properties sont valides
                Class.forName(property_DRIVER);
                //Contrainte n° 3 vérifié :le driver jdbc est bien présent et chargé
                property_URL= property_URL + "/" +property_DBNAME;
                instance =new  ;


            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        }
    }

    private static void close() {
    }


    public static Connection getConnection(){
        return null;
    }
public IDao<Crédit,Long> getCréditDao(){

    return null;
}

}
