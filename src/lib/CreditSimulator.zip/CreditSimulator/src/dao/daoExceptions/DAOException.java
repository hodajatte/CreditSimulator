package dao.daoExceptions;

public class DAOException {

}
