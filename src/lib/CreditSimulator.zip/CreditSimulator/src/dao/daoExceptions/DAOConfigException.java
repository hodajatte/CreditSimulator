package dao.daoExceptions;

public class DAOConfigException extends Throwable {

    public DAOConfigException(String s) {
    }
}
